﻿function btnTraceProgress1SearchOnClick() {
    $("#filter-search").css('display', 'inline-block');
}



function MapRefresh() {
    $('#tdmap').css('display', 'block');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');

    $('#tab1').prop('checked', false);
    $('#tab2').prop('checked', false);
    $('#tab3').prop('checked', false);
}

function divgraph1_Chart1Onlcike() {
    //GetRegion();
    $('#tdmap').css('display', 'none');
    $('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'block');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');

    $('#DC01').prop('checked', true);
}

function divgraph2_Chart1Onlcike() {
    $('#tdmap').css('display', 'none');
    $('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'block');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');

    $('#DC02').prop('checked', true);
}

function divgraph3_Chart1Onlcike() {
    $('#tdmap').css('display', 'none');
    $('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'block');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');

    $('#DC03').prop('checked', true);
}

// === Tab system onclick Search + refresh
function TabLoginHistoryOnclick() {
    $('#tdmap').css('display', 'none');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'block');


    var Province__Select__Text = $('#province option:selected').text();
    var Province__Select__Value = $('#province option:selected').val();
    var dateOnlyStart__Value = $('#dateOnlyStart').val();
    var dateOnlyEnd__Value = $('#dateOnlyEnd').val();
     
    $('#ProvincetabSystem').text(Province__Select__Text);
    $('#dateSearchStart').text(dateOnlyStart__Value);
    $('#dateSearchEnd').text(dateOnlyEnd__Value);
}

function btnSystemRefresh() {
    $('#tdmap').css('display', 'block');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');
}

function TabTraceProgressByProvinceOnclick() {
    $('#tdmap').css('display', 'none');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'block');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');
}

function TabTraceProgressByDistrictOnclick() {
    $('#tdmap').css('display', 'none');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'block');
    $('#divTraceProgressByTambon').css('display', 'none');
    $('#divTabSystemTable').css('display', 'none');
}


function TabTraceProgressByTambonOnclick() {
    $('#tdmap').css('display', 'none');
    //$('#divGraph').css('display', 'none');
    $('#divGraphNew').css('display', 'none');
    $('#divTraceProgressByRegion').css('display', 'none');
    $('#divTraceProgressByProvince').css('display', 'none');
    $('#divTraceProgressByDistrict').css('display', 'none');
    $('#divTraceProgressByTambon').css('display', 'block');
    $('#divTabSystemTable').css('display', 'none');
}




 