﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class PARCEL_Model
    {
        public int OBJECTID { get; set; }
        public Nullable<int> OGR_FID { get; set; }
        public Nullable<int> PARCEL_TYPE { get; set; }
        public string UTMMAP1 { get; set; }
        public Nullable<int> UTMMAP2 { get; set; }
        public string UTMMAP3 { get; set; }
        public string UTMMAP4 { get; set; }
        public Nullable<int> UTMSCALE { get; set; }
        public Nullable<int> LAND_NO { get; set; }
        public string LAND_TH { get; set; }
        public string LAND_NAME { get; set; }
        public string ACTION_STATUS { get; set; }
        public string LAND_AREA { get; set; }
        public string BRANCH_CODE { get; set; }
        public string BRANCH_NAME { get; set; }
        public string CHANGWAT_CODE { get; set; }
        public string CHANGWAT_NAME { get; set; }
        public string AMPHUR_CODE { get; set; }
        public string AMPHUR_NAME { get; set; }
        public string TUMBON_CODE { get; set; }
        public string TUMBON_NAME { get; set; }
        public Nullable<int> CHANOD_NO { get; set; }
        public Nullable<int> SURVEY_NO { get; set; }
        public Nullable<int> TABLE_3_SEQ { get; set; }
        public string ACCOUNTING_PERIOD { get; set; }
        public Nullable<int> PARCEL_SHAPE { get; set; }
        public Nullable<int> PARCEL_RN { get; set; }
        public Nullable<int> STREET_RN { get; set; }
        public Nullable<int> BLOCK_ZONE_RN { get; set; }
        public Nullable<int> BLOCK_PRICE_RN { get; set; }
        public Nullable<int> BLOCK_FIX_RN { get; set; }
        public Nullable<int> BLOCK_BLUE_RN { get; set; }
        public Nullable<decimal> PREV_EVAPRICE { get; set; }
        public Nullable<decimal> CURR_EVAPRICE { get; set; }
        public Nullable<System.DateTime> DATE_CREATED { get; set; }
        public string USER_CREATED { get; set; }
        public Nullable<System.DateTime> DATE_UPDATED { get; set; }
        public string USER_UPDATED { get; set; }
        public System.Data.Entity.Spatial.DbGeometry SHAPE { get; set; }
        public string EDIT_FLAG { get; set; }
    }
}