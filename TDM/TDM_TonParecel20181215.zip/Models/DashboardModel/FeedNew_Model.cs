﻿namespace TDM.Models.DashboardModel
{
    public class FeedNew_Model
    {
        public FeedNew_Model(string topic_Name, string topic_Date, string create_By,string url)
        {
            Topic_Name = topic_Name;
            Topic_Date = topic_Date;
            Create_By = create_By;
            Url = url;
        }

        public string Topic_Name { get; set; }
        public string Topic_Date { get; set; }
        public string Create_By { get; set; }
        public string Url { get; set; }
    }
}