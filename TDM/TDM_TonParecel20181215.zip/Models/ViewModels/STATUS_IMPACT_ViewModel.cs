﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class STATUS_IMPACT_ViewModel
    {
        public int ID { get; set; }
        public string STATUS_NAME { get; set; }
    }
}