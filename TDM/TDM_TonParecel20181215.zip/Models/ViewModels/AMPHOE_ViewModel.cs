﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class AMPHOE_ViewModel
    {
        public int OBJECTID { get; set; }
        public string ON_PRO_THA { get; set; }
        public string ON_PRO_ENG { get; set; }
        public string PRO_C { get; set; }
        public string ON_DIS_THA { get; set; }
        public string ON_DIS_ENG { get; set; }
        public string DIS_C { get; set; }
        public string NAME_T { get; set; }
        public string NAME_E { get; set; }
    }
}