﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class POI_ViewModel
    {
        public int OBJECTID { get; set; }
        public Nullable<int> FID_1 { get; set; }
        public Nullable<int> ID { get; set; }
        public string CODE { get; set; }
        public string SUB_CODE1 { get; set; }
        public string SUB_CODE2 { get; set; }
        public string NAME_E { get; set; }
        public string NAME_T { get; set; }
        public Nullable<decimal> X { get; set; }
        public Nullable<decimal> Y { get; set; }
        public string PROV_NAME_T { get; set; }
        public string PROV_NAME_E { get; set; }
        public string PROV_CODE { get; set; }
        public string AMPH_CODE { get; set; }
        public string AMPH_NAME_T { get; set; }
        public string AMPH_NAME_E { get; set; }
        public string TUMB_CODE { get; set; }
        public string TUMB_NAME_T { get; set; }
        public string TUMB_NAME_E { get; set; }
        public Nullable<System.DateTime> DATE_CREATED { get; set; }
        public string USER_CREATED { get; set; }
        public Nullable<System.DateTime> DATE_UPDATED { get; set; }
        public string USER_UPDATED { get; set; }
        public string POI_TYPE { get; set; }
        public string USER_TYPE { get; set; }
        public System.Data.Entity.Spatial.DbGeometry Shape { get; set; }
        public byte[] GDB_GEOMATTR_DATA { get; set; }
    }
}