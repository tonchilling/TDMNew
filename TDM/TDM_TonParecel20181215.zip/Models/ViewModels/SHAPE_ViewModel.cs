﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class SHAPE_ViewModel
    {
        public string SHAPE { get; set; }
        public SHAPE_ViewModel(System.Data.Entity.Spatial.DbGeometry Shape) {
            SHAPE = Shape.ToString();
        }
    }
}