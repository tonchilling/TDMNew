﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TDM.Models
{
    public class TAMBOL_ViewModel
    {
        public int OBJECTID { get; set; }
        public Nullable<decimal> TDASSETNON_TDADMIN_TAMBOL_AREA { get; set; }
        public Nullable<decimal> PERIMETER { get; set; }
        public string ON_PRO_THA { get; set; }
        public string ON_PRO_ENG { get; set; }
        public string PRO_C { get; set; }
        public string ON_DIS_THA { get; set; }
        public string ON_DIS_ENG { get; set; }
        public string DIS_C { get; set; }
        public string ON_SUB_THA { get; set; }
        public string ON_SUB_ENG { get; set; }
        public string SUB_C { get; set; }
        public string NAME_E { get; set; }
        public string NAME_T { get; set; }
    }
}