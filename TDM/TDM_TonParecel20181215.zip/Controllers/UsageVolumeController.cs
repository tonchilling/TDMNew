﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TDM.Models;

namespace TDM.Controllers
{
    public class UsageVolumeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}