﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TDM.Controllers
{
    public class DashboardSystem3Controller : Controller
    {
        // GET: DashboardSystem3
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult IndexTu()
        {
            return View();
        }


        // GET: DashboardSystem3
        public ActionResult ViewList()
        {
            return View();
        }
    }
}